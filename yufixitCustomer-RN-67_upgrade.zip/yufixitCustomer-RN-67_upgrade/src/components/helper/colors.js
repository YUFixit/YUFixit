export const mainColor = '#0D6176'
export const mainWhite = '#fff'